package game;

public class Level2 extends LevelState{

	public Level2(Game game) {
		super(game);
		
	}

	@Override
	public int addPoints(int newPoints) {
		int totalPoints = game.getTotalPoints() + 2*newPoints;
        if (totalPoints > 15) { 
            LevelState level2_5=new Level2_5(game);
            game.setState(level2_5);
            totalPoints = totalPoints + 1;
        }
        return totalPoints;
	}

	@Override
	public String updateLevel() {	
		return "2";
	}

	
}
