package game;

import java.util.Random;

public class Game {
	private LevelState levelState;
	private int totalPoints = 0;
	
	public int getTotalPoints() {
		return totalPoints;
		
	}
	public void setState(LevelState state) {
		this.levelState = state;
	}
	
	public void play() {
		Random random = new Random();
		totalPoints = levelState.addPoints(random.nextInt(7));
		System.out.println("points="+totalPoints+" level="+ levelState.updateLevel());
	}

	

}
