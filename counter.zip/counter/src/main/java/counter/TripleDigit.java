package counter;

public class TripleDigit extends CounterState {

	public TripleDigit(Counter counter) {
		super(counter);
		
	}
	@Override
	public int increment() {
		int count = counter.getCount();
		count = count + 3;		
		return count;
	}

	@Override
	public int decrement() {
		 int count=counter.getCount();
		 count = count - 3;	     
	     return count;
		
	}

}
