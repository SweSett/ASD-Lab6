package counter;

public class SingleDigit extends CounterState {

	public SingleDigit(Counter counter) {
		super(counter);
		
	}

	@Override
	public int increment() {
		int count = counter.getCount();
		count++;
		if(Integer.toString(count).length()==2)
			counter.setState(new DoubleDigit(counter));
		return count;
	}

	@Override
	public int decrement() {
		 int count=counter.getCount();
		 count--;
	        if(Integer.toString(count).length()==2)
	            counter.setState(new DoubleDigit(counter));
	        return count;
		
	}

}
