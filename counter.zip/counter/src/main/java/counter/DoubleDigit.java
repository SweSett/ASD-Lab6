package counter;

public class DoubleDigit extends CounterState{

	public DoubleDigit(Counter counter) {
		super(counter);
	
	}

	@Override
	public int increment() {
		int count = counter.getCount();
		count = count + 2;
		if(Integer.toString(count).length()==3)
			counter.setState(new TripleDigit(counter));
		return count;
	}

	@Override
	public int decrement() {
		 int count=counter.getCount();
		 count = count - 2;
	        if(Integer.toString(count).length()==3)
	            counter.setState(new TripleDigit(counter));
	        return count;
		
	}
	

}
