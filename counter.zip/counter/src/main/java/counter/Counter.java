package counter;

import java.util.Observable;

public class Counter  extends Observable{
	private CounterState counterState;
	private int count=0;
	
	public Counter() {
		counterState = new SingleDigit(this);
	}
	public int getCount() {
		return count;
	}
	
	public void setState(CounterState state){
		counterState=state;
	}	

	public void increment(){
		count = counterState.increment();
		System.out.println("Count : " + count  +", State : "+ counterState.getClass().getSimpleName());
    	setChanged();
    	notifyObservers(count);
	}
	
	public void decrement(){
		count = counterState.decrement();
		setChanged();
    	notifyObservers(count);
	}
}
